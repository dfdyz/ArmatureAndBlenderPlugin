# SPDX-License-Identifier: GPL-3.0-or-later
"""Main IK/FK, baking and projection sidebar panel."""

import bpy
from . import baking, projection, switching


class VIEW3D_PT_ik_fk_switch(bpy.types.Panel):
    bl_label = "IK / FK Switch"
    bl_idname = "VIEW3D_PT_ik_fk_switch"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        available = switching._SwitchModeOperator.poll(context)
        column = layout.column(align=True)
        column.enabled = available
        column.scale_y = 1.4
        modes = column.row(align=True)
        modes.operator(switching.POSE_OT_ik_fk_switch_to_ik.bl_idname, text="IK Mode")
        modes.operator(switching.POSE_OT_ik_fk_switch_to_fk.bl_idname, text="FK Mode")
        column.operator(switching.POSE_OT_ik_fk_disable_all.bl_idname, text="DisableAll")
        layout.separator()
        bake_column = layout.column(align=True)
        bake_column.enabled = baking.POSE_OT_ik_fk_bake.poll(context)
        bake_column.prop(context.scene, "ik_fk_bake_step")
        bake_column.prop(context.scene, "ik_fk_bake_min_samples")
        bake_column.prop(context.scene, "ik_fk_bake_max_samples")
        bake_column.operator(baking.POSE_OT_ik_fk_bake.bl_idname, text="Bake")
        bake_column.operator(baking.POSE_OT_ik_fk_bake_current_frame.bl_idname)
        bake_column.operator(baking.POSE_OT_ik_fk_bake_selected_frames.bl_idname)
        layout.separator()
        projection_box = layout.box()
        projection_box.label(text="关键帧投影")
        row = projection_box.row(align=True)
        row.operator(projection.POSE_OT_ik_fk_snapshot_keyframes.bl_idname)
        row.operator(projection.POSE_OT_ik_fk_print_keyframes.bl_idname)
        projection_box.label(text=f"已记录 {len(context.scene.ik_fk_projection_frames)} 个帧号")
        if not available:
            layout.label(text="Select an armature in Pose Mode", icon="INFO")
