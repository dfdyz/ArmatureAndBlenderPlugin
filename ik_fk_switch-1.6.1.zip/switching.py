# SPDX-License-Identifier: GPL-3.0-or-later
"""Global and scoped IK/FK constraint switching."""

import bpy
from . import pose


def switch_mode(context, mode, *, bone_names=None):
    """Snapshot -> cache local matrices -> mute -> apply pose -> optionally unmute.

    Constraint influence and animation are deliberately preserved. Returns the
    number of constraints matched by the disable and enable prefixes.
    DISABLE_ALL mutes both IK_* and FK_* and never unmutes any constraints.
    bone_names limits writes and constraint changes to those members. Capture
    the entire rig so a member's parent can still be converted when outside it.
    """
    if mode not in {"IK", "FK", "DISABLE_ALL"}:
        raise ValueError("Mode must be IK, FK or DISABLE_ALL")
    armature = context.active_object
    if not (
        armature
        and armature.type == "ARMATURE"
        and armature.mode == "POSE"
        and armature.is_editable
    ):
        raise ValueError("Select an editable armature in Pose Mode")

    names = set(armature.pose.bones.keys()) if bone_names is None else set(bone_names)
    if not names:
        raise ValueError("The active bone group has no bones")
    if not names.issubset(armature.pose.bones.keys()):
        raise ValueError("Bone group contains bones outside the active armature")
    bones = [bone for bone in armature.pose.bones if bone.name in names]
    levels = [[bone for bone in level if bone.name in names] for level in pose._bone_levels(armature)]
    levels = [level for level in levels if level]
    world_matrices = pose._world_pose(context, armature)
    local_matrices = pose._world_to_local_pose(context, armature, world_matrices)
    local_matrices = {name: local_matrices[name] for name in names}
    old_channels = {
        bone.name: pose._local_channels(bone) for bone in bones
    }
    if mode == "DISABLE_ALL":
        disable_prefixes = ("IK_", "FK_")
        enable_prefixes = ()
    else:
        disable_prefixes = ("FK_",) if mode == "IK" else ("IK_",)
        enable_prefixes = (mode + "_",)
    disable = []
    enable = []
    for bone in bones:
        for constraint in bone.constraints:
            # Case-sensitive prefix matching is equivalent to FK_* / IK_*.
            if constraint.name.startswith(disable_prefixes):
                disable.append(constraint)
            elif constraint.name.startswith(enable_prefixes):
                enable.append(constraint)
    old_mutes = [(constraint, constraint.mute) for constraint in disable + enable]

    try:
        # Finish disabling ALL old-mode constraints before enabling ANY new
        # ones. Do not interleave disable/enable operations while scanning.
        for constraint in disable:
            constraint.mute = True
        context.view_layer.update()

        pose._apply_local_pose(context, local_matrices, levels)

        for constraint in enable:
            constraint.mute = False
        context.view_layer.update()
    except Exception:
        # A cancelled operator should not leave a partially switched rig.
        for name, channels in old_channels.items():
            bone = armature.pose.bones[name]
            for attribute, value in channels.items():
                setattr(bone, attribute, value)
        for constraint, muted in old_mutes:
            constraint.mute = muted
        context.view_layer.update()
        raise

    return len(disable), len(enable)


class _SwitchModeOperator:
    group_only = False

    @classmethod
    def poll(cls, context):
        armature = context.active_object
        available = bool(
            armature
            and armature.type == "ARMATURE"
            and armature.mode == "POSE"
            and armature.is_editable
        )
        if available and cls.group_only:
            group = armature.data.collections.active
            return bool(group and group.bones)
        return available

    def execute(self, context):
        try:
            if self.group_only:
                group = context.active_object.data.collections.active
                if group is None:
                    raise ValueError("Select a bone group in the list")
                disabled, enabled = switch_mode(
                    context, self.target_mode, bone_names={bone.name for bone in group.bones},
                )
            else:
                disabled, enabled = switch_mode(context, self.target_mode)
        except Exception as error:
            self.report({"ERROR"}, f"IK / FK switch failed: {error}")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"{self.bl_label}: disabled {disabled}, enabled {enabled} constraints",
        )
        return {"FINISHED"}


class POSE_OT_ik_fk_switch_to_ik(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_switch_to_ik"
    bl_label = "IK Mode"
    bl_description = "Bake the current pose, disable FK_* and enable IK_* constraints"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "IK"


class POSE_OT_ik_fk_switch_to_fk(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_switch_to_fk"
    bl_label = "FK Mode"
    bl_description = "Bake the current pose, disable IK_* and enable FK_* constraints"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "FK"


class POSE_OT_ik_fk_disable_all(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_disable_all"
    bl_label = "DisableAll"
    bl_description = "Cache the current pose, disable IK_* and FK_*, then apply the pose"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "DISABLE_ALL"
