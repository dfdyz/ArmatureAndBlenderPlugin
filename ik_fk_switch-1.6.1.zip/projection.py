# SPDX-License-Identifier: GPL-3.0-or-later
"""Frame-only snapshots and printing the current pose at saved times."""

import bpy
from . import baking, keyframes, pose, switching


def snapshot_keyframe_times(context):
    """Store only selected scene-frame numbers, without source-rig references."""
    armature = context.active_object
    if not armature or armature.type != "ARMATURE":
        raise ValueError("Select an armature to snapshot keyframe times")
    frames = keyframes._selected_keyframe_times(armature)
    if not frames:
        raise ValueError("Select at least one keyframe in the active armature's Action")
    snapshot = context.scene.ik_fk_projection_frames
    snapshot.clear()
    for frame in frames:
        snapshot.add().frame = frame
    return frames


def print_keyframe_times(context):
    """Key one current set of local channels at all snapshotted frame times."""
    if not switching._SwitchModeOperator.poll(context):
        raise ValueError("Select an editable armature in Pose Mode")
    armature = context.active_object
    bones = [bone for bone in armature.pose.bones if bone.bone.select]
    if not bones:
        raise ValueError("Select at least one pose bone to print keyframes")
    frames = sorted({item.frame for item in context.scene.ik_fk_projection_frames})
    if not frames:
        raise ValueError("Snapshot keyframe times before printing")
    channels = {bone.name: pose._local_channels(bone) for bone in bones}
    had_animation_data = armature.animation_data is not None
    original_action = armature.animation_data.action if had_animation_data else None
    if original_action and not original_action.is_editable:
        raise ValueError("The active Action is not editable")
    paths, original_keys = keyframes._snapshot_transform_keys(armature, bones)
    try:
        previous_rotations = {}
        for frame in frames:
            # Never frame_set(): every destination gets the same current pose,
            # including unkeyed edits, regardless of its existing animation.
            keyframes._insert_transform_keys(bones, frame, previous_rotations)
    except Exception:
        keyframes._rollback_transform_keys(armature, original_action, had_animation_data, paths, original_keys)
        raise
    finally:
        for bone in bones:
            for attribute, value in channels[bone.name].items():
                setattr(bone, attribute, value)
        context.view_layer.update()
    return len(bones), frames


class IKFK_PG_projection_frame(bpy.types.PropertyGroup):
    frame: bpy.props.FloatProperty(name="Frame", options=set())


class POSE_OT_ik_fk_snapshot_keyframes(bpy.types.Operator):
    bl_idname = "pose.ik_fk_snapshot_keyframes"
    bl_label = "快照"
    bl_description = "记录当前活动骨架 Action 中选中的帧号，仅保存帧号，可用于其他骨架"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(context.active_object and context.active_object.type == "ARMATURE")

    def execute(self, context):
        try:
            frames = snapshot_keyframe_times(context)
        except Exception as error:
            self.report({"ERROR"}, f"快照失败：{error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已记录 {len(frames)} 个帧号")
        return {"FINISHED"}


class POSE_OT_ik_fk_print_keyframes(bpy.types.Operator):
    bl_idname = "pose.ik_fk_print_keyframes"
    bl_label = "打印"
    bl_description = "将当前所选骨骼的位置、旋转和缩放写入快照记录的所有帧号"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return baking.POSE_OT_ik_fk_bake.poll(context) and bool(context.scene.ik_fk_projection_frames)

    def execute(self, context):
        try:
            count, frames = print_keyframe_times(context)
        except Exception as error:
            self.report({"ERROR"}, f"打印失败：{error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已为 {count} 根骨骼打印 {len(frames)} 帧")
        return {"FINISHED"}
