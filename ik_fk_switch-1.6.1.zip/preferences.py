# SPDX-License-Identifier: GPL-3.0-or-later
"""Editable shortcuts and addon preferences."""

import bpy
import rna_keymap_ui
from . import baking, switching


_SHORTCUTS = (
    (switching.POSE_OT_ik_fk_switch_to_ik, "I"),
    (switching.POSE_OT_ik_fk_switch_to_fk, "F"),
    (baking.POSE_OT_ik_fk_bake, "B"),
)


_addon_keymaps = []


def _register_keymaps():
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return  # Key configurations can be unavailable in background sessions.
    keymap = keyconfig.keymaps.new(name="Pose", space_type="EMPTY", region_type="WINDOW")
    for operator, key in _SHORTCUTS:
        item = keymap.keymap_items.new(
            operator.bl_idname, type=key, value="PRESS", ctrl=True, shift=True,
        )
        _addon_keymaps.append((keymap, item))


def _unregister_keymaps():
    for keymap, item in _addon_keymaps:
        keymap.keymap_items.remove(item)
    _addon_keymaps.clear()


class IKFK_AP_preferences(bpy.types.AddonPreferences):
    # Extensions use the full bl_ext.<repository>.<package> module identifier.
    bl_idname = __package__ or __name__

    def draw(self, context):
        layout = self.layout
        layout.label(text="Shortcuts (Pose Mode)")
        # Edit the USER keymap, not the add-on defaults, so Blender can save
        # custom bindings and restore defaults through its native keymap UI.
        keyconfig = context.window_manager.keyconfigs.user
        keymap = keyconfig.keymaps.get("Pose") if keyconfig else None
        for operator, _key in _SHORTCUTS:
            items = (
                [item for item in keymap.keymap_items if item.idname == operator.bl_idname]
                if keymap else []
            )
            if not items:
                layout.label(text=f"{operator.bl_label}: unassigned (Preferences > Keymap)")
                continue
            for item in items:
                column = layout.column()
                column.context_pointer_set("keymap", keymap)
                rna_keymap_ui.draw_kmi([], keyconfig, keymap, item, column, 0)
