# SPDX-License-Identifier: GPL-3.0-or-later
"""Action slots, selected frame times, transform keys and rollback."""

import bpy


def _action_curve_collections(armature):
    """Read only this object's assigned Action slot (including legacy Actions)."""
    animation = armature.animation_data
    if not animation or not animation.action:
        return []
    action = animation.action
    if action.is_action_legacy:
        return [action.fcurves]
    slot = animation.action_slot
    if slot is None:
        return []
    collections = []
    for layer in action.layers:
        for strip in layer.strips:
            if strip.type == "KEYFRAME":
                channelbag = strip.channelbag(slot)
                if channelbag is not None:
                    collections.append(channelbag.fcurves)
    return collections


def _selected_keyframe_times(armature, bones=None):
    # Projection snapshots only need times, so they may read every channel
    # in the active slot. Baking still filters by its selected pose bones.
    prefixes = None if bones is None else tuple(
        bone.path_from_id() + suffix for bone in bones for suffix in (".", "[")
    )
    animation = armature.animation_data
    times = set()
    for curves in _action_curve_collections(armature):
        for curve in curves:
            if prefixes is not None and not curve.data_path.startswith(prefixes):
                continue
            for key in curve.keyframe_points:
                if key.select_control_point:
                    frame = key.co.x
                    if animation.use_tweak_mode:
                        frame = animation.nla_tweak_strip_time_to_scene(frame)
                    # Location/rotation/scale channels on one frame count once.
                    times.add(round(frame, 6))
    return sorted(times)


def _rotation_path(bone):
    if bone.rotation_mode == "QUATERNION":
        return "rotation_quaternion"
    if bone.rotation_mode == "AXIS_ANGLE":
        return "rotation_axis_angle"
    return "rotation_euler"


_KEYFRAME_ATTRIBUTES = (
    "co", "handle_left", "handle_right", "handle_left_type", "handle_right_type",
    "interpolation", "easing", "amplitude", "back", "period", "type",
    "select_control_point", "select_left_handle", "select_right_handle",
)


def _snapshot_transform_keys(armature, bones):
    paths = {
        bone.path_from_id(path)
        for bone in bones for path in ("location", _rotation_path(bone), "scale")
    }
    snapshots = {}
    for curves in _action_curve_collections(armature):
        for curve in curves:
            if curve.data_path in paths:
                points = []
                for key in curve.keyframe_points:
                    values = {}
                    for attribute in _KEYFRAME_ATTRIBUTES:
                        value = getattr(key, attribute)
                        values[attribute] = value.copy() if hasattr(value, "copy") else value
                    points.append(values)
                snapshots[curve.as_pointer()] = points
    return paths, snapshots


def _restore_transform_keys(armature, paths, snapshots):
    for curves in _action_curve_collections(armature):
        for curve in list(curves):
            if curve.data_path not in paths:
                continue
            points = snapshots.get(curve.as_pointer())
            if points is None:
                curves.remove(curve)
                continue
            curve.keyframe_points.clear()
            curve.keyframe_points.add(len(points))
            for key, values in zip(curve.keyframe_points, points):
                for attribute, value in values.items():
                    setattr(key, attribute, value)
            curve.update()


def _rollback_transform_keys(armature, original_action, had_animation_data, paths, snapshots):
    if original_action:
        _restore_transform_keys(armature, paths, snapshots)
    elif armature.animation_data:
        new_action = armature.animation_data.action
        armature.animation_data.action = None
        if not had_animation_data:
            armature.animation_data_clear()
        if new_action and new_action.users == 0:
            bpy.data.actions.remove(new_action)


def _insert_transform_keys(bones, frame, previous_rotations):
    for bone in bones:
        rotation_path = _rotation_path(bone)
        if rotation_path != "rotation_axis_angle":
            rotation = getattr(bone, rotation_path).copy()
            previous = previous_rotations.get(bone.name)
            if previous is not None:
                rotation.make_compatible(previous)
                setattr(bone, rotation_path, rotation)
            previous_rotations[bone.name] = rotation
        for path in ("location", rotation_path, "scale"):
            if not bone.keyframe_insert(data_path=path, index=-1, frame=frame, options=set()):
                raise RuntimeError(f"Could not insert {bone.name}: {path} at frame {frame:g}")
