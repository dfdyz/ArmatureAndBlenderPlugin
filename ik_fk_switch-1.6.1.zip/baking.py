# SPDX-License-Identifier: GPL-3.0-or-later
"""Current, range and selected-frame pose baking."""

import bpy
from math import floor
from . import keyframes, pose, switching


def _bake_frame_times(context, armature, bones, step, selected_only=False):
    selected = keyframes._selected_keyframe_times(armature, bones)
    if selected_only:
        if not selected:
            raise ValueError("Select at least one keyframe on the selected bones")
        return selected
    if not isinstance(step, int) or step < 1:
        raise ValueError("Frame Step must be a positive integer")
    if len(selected) < 2:
        # Do not jump to a single selected key, or reset manually edited poses.
        return [context.scene.frame_current + context.scene.frame_subframe]
    start, end = selected[0], selected[-1]
    frames = [start + offset * step for offset in range(floor((end - start) / step) + 1)]
    if abs(frames[-1] - end) > 1e-6:
        frames.append(end)
    return frames


def bake_pose(context, step=1, *, selected_only=False, current_only=False):
    """Sample with the existing local conversion, then key selected pose bones.

    No constraint is toggled. A single selected frame means key the current
    pose at the playhead; two or more distinct frames define a bake interval.
    With selected_only=True, sample the exact selected times, even a lone key.
    With current_only=True, ignore key selection and bake the current pose.
    """
    if not switching._SwitchModeOperator.poll(context):
        raise ValueError("Select an editable armature in Pose Mode")
    armature = context.active_object
    bones = [bone for bone in armature.pose.bones if bone.bone.select]
    if not bones:
        raise ValueError("Select at least one pose bone to bake")
    if current_only and selected_only:
        raise ValueError("Choose either current-frame or selected-frame baking")
    frames = (
        [context.scene.frame_current + context.scene.frame_subframe]
        if current_only else _bake_frame_times(context, armature, bones, step, selected_only)
    )
    sample_animation = not current_only and (selected_only or len(frames) > 1)
    names = {bone.name for bone in bones}
    levels = [
        [bone for bone in level if bone.name in names]
        for level in pose._bone_levels(armature)
    ]
    levels = [level for level in levels if level]
    scene = context.scene
    original_frame, original_subframe = scene.frame_current, scene.frame_subframe
    old_channels = {bone.name: pose._local_channels(bone) for bone in armature.pose.bones}
    had_animation_data = armature.animation_data is not None
    original_action = armature.animation_data.action if had_animation_data else None
    if original_action and not original_action.is_editable:
        raise ValueError("The active Action is not editable")
    paths, original_keys = keyframes._snapshot_transform_keys(armature, bones)
    writing = False
    success = False
    try:
        samples = []
        for frame in frames:
            world = pose._stable_world_pose(
                context, armature, frame=frame if sample_animation else None,
            )
            local = pose._world_to_local_pose(context, armature, world)
            samples.append((frame, {name: local[name] for name in names}))

        # Finish sampling the original animation before inserting ANY keys.
        writing = True
        previous_rotations = {}
        for frame, local in samples:
            pose._apply_local_pose(context, local, levels)
            keyframes._insert_transform_keys(bones, frame, previous_rotations)
        # Restore a stable displayed pose as well. If the written animation
        # does not settle, use the same keyframe rollback as other failures.
        pose._stable_world_pose(
            context, armature,
            frame=original_frame + original_subframe if sample_animation else None,
        )
        success = True
    except Exception:
        if writing:
            keyframes._rollback_transform_keys(armature, original_action, had_animation_data, paths, original_keys)
        raise
    finally:
        if sample_animation and not success:
            scene.frame_set(original_frame, subframe=original_subframe)
        if not success:
            for name, channels in old_channels.items():
                for attribute, value in channels.items():
                    setattr(armature.pose.bones[name], attribute, value)
        context.view_layer.update()
    return len(bones), frames


class _BakePoseOperator:
    selected_only = False
    current_only = False

    @classmethod
    def poll(cls, context):
        return switching._SwitchModeOperator.poll(context) and any(
            bone.bone.select for bone in context.active_object.pose.bones
        )

    def execute(self, context):
        try:
            count, frames = bake_pose(
                context, context.scene.ik_fk_bake_step, selected_only=self.selected_only,
                current_only=self.current_only,
            )
        except Exception as error:
            self.report({"ERROR"}, f"Bake failed: {error}")
            return {"CANCELLED"}
        interval = f"{frames[0]:g}" if len(frames) == 1 else f"{frames[0]:g}-{frames[-1]:g}"
        self.report({"INFO"}, f"Baked {count} bones, {len(frames)} frames ({interval})")
        return {"FINISHED"}


class POSE_OT_ik_fk_bake(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake"
    bl_label = "Bake"
    bl_description = "Key selected bones at the current frame, or bake between two or more selected frames"
    bl_options = {"REGISTER", "UNDO"}


class POSE_OT_ik_fk_bake_current_frame(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake_current_frame"
    bl_label = "烘焙到当前帧"
    bl_description = "忽略关键帧选择，将所选骨骼的当前约束姿态烘焙到播放头所在帧，保留未插帧的手动调整"
    bl_options = {"REGISTER", "UNDO"}
    current_only = True


class POSE_OT_ik_fk_bake_selected_frames(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake_selected_frames"
    bl_label = "烘焙选中帧"
    bl_description = "在所有选中的关键帧位置重采样并烘焙所选骨骼，不填充中间帧"
    bl_options = {"REGISTER", "UNDO"}
    selected_only = True


def _update_min_samples(scene, _context):
    if scene.ik_fk_bake_min_samples > scene.ik_fk_bake_max_samples:
        scene.ik_fk_bake_max_samples = scene.ik_fk_bake_min_samples


def _update_max_samples(scene, _context):
    if scene.ik_fk_bake_max_samples < scene.ik_fk_bake_min_samples:
        scene.ik_fk_bake_min_samples = scene.ik_fk_bake_max_samples
