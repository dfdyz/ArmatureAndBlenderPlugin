# SPDX-License-Identifier: GPL-3.0-or-later
"""Evaluated poses, stability sampling and local-space conversion."""

import bpy
from math import floor, isfinite


def _bone_levels(armature):
    """Return every pose bone, with parents in an earlier level."""
    level = [bone for bone in armature.pose.bones if bone.parent is None]
    levels = []
    while level:
        levels.append(level)
        level = [child for bone in level for child in bone.children]
    return levels


def _world_pose(context, armature):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = armature.evaluated_get(depsgraph)
    # PoseBone.matrix is in armature space and includes evaluated constraints.
    # Copy values: dependency graph updates invalidate evaluated data references.
    return {
        bone.name: evaluated.matrix_world @ bone.matrix
        for bone in evaluated.pose.bones
    }


_POSE_STABILITY_TOLERANCE = 1e-6


def _pose_delta(previous, current):
    largest, changed_bone = 0.0, ""
    for name, matrix in current.items():
        for row in range(4):
            for column in range(4):
                delta = abs(matrix[row][column] - previous[name][row][column])
                if not isfinite(delta):
                    raise RuntimeError(f"Non-finite pose matrix on bone '{name}'")
                if delta > largest:
                    largest, changed_bone = delta, name
    return largest, changed_bone


def _stable_world_pose(context, armature, *, frame=None):
    """Require consecutive evaluated world poses to agree before baking.

    Animated sampling re-evaluates the same frame. Current-pose sampling tags
    object transforms instead, preserving unkeyed edits and avoiding an
    animation reset. Plain view_layer.update() does not dirty cyclic inputs.
    """
    minimum = context.scene.ik_fk_bake_min_samples
    maximum = context.scene.ik_fk_bake_max_samples
    previous = None
    delta, changed_bone = 0.0, ""
    for attempt in range(maximum):
        if frame is not None:
            context.scene.frame_set(floor(frame), subframe=frame - floor(frame))
        elif attempt:
            # Include constraint targets and other rigs in the view layer:
            # an inter-object dependency cycle may cross armature boundaries.
            # Do not tag TIME/ANIMATION, which would discard manual edits.
            for obj in context.view_layer.objects:
                obj.update_tag(refresh={"OBJECT"})
        current = _world_pose(context, armature)
        if previous is not None:
            delta, changed_bone = _pose_delta(previous, current)
            # The initial read counts as one sample. Never accept an early
            # agreement before the user's minimum number of evaluations.
            if attempt + 1 >= minimum and delta <= _POSE_STABILITY_TOLERANCE:
                return current
        previous = current

    current_frame = context.scene.frame_current + context.scene.frame_subframe
    raise RuntimeError(
        f"Pose did not stabilize at frame {current_frame:g} after "
        f"{maximum} evaluations "
        f"(bone '{armature.name}/{changed_bone}', matrix delta {delta:.6g})"
    )


def _local_channels(bone):
    """Keep original channels, including Euler winding, for error recovery."""
    return {
        "location": bone.location.copy(),
        "rotation_euler": bone.rotation_euler.copy(),
        "rotation_quaternion": bone.rotation_quaternion.copy(),
        "rotation_axis_angle": tuple(bone.rotation_axis_angle),
        "scale": bone.scale.copy(),
    }


def _world_to_local_pose(context, armature, world_matrices):
    """Calculate ALL local matrices before changing constraints or channels."""
    evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
    world_to_armature = evaluated.matrix_world.inverted()
    pose_matrices = {
        name: world_to_armature @ matrix for name, matrix in world_matrices.items()
    }
    local_matrices = {}
    for bone in armature.pose.bones:
        parent_args = {}
        if bone.parent:
            parent_args = {
                # Use the parent's captured constrained pose, never its pose
                # after constraints have been muted or channels overwritten.
                "parent_matrix": pose_matrices[bone.parent.name],
                "parent_matrix_local": bone.parent.bone.matrix_local,
            }
        # Handles rest matrices, Local Location, Inherit Rotation and the
        # different Inherit Scale modes. A plain parent inverse does not.
        local_matrices[bone.name] = bone.bone.convert_local_to_pose(
            pose_matrices[bone.name],
            bone.bone.matrix_local,
            invert=True,
            **parent_args,
        )
    return local_matrices


def _apply_local_pose(context, local_matrices, levels):
    """Apply the cached local matrices only after old constraints are muted."""
    for level in levels:
        for bone in level:
            bone.matrix_basis = local_matrices[bone.name]
        context.view_layer.update()
