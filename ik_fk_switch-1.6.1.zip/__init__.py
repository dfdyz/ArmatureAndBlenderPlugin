# SPDX-License-Identifier: GPL-3.0-or-later
"""IK / FK Switch addon entry point and registration."""

import bpy


bl_info = {
    "name": "IK / FK Switch",
    "author": "IK / FK Switch Contributors",
    "version": (1, 6, 1),
    "blender": (4, 5, 0),
    "location": "3D Viewport > Sidebar > IK / FK",
    "description": "Bake the current pose and switch IK_* / FK_* constraints",
    "category": "Rigging",
}


from . import baking, bone_groups, preferences, projection, switching, ui


_CLASSES = (
    projection.IKFK_PG_projection_frame,
    switching.POSE_OT_ik_fk_switch_to_ik,
    switching.POSE_OT_ik_fk_switch_to_fk,
    switching.POSE_OT_ik_fk_disable_all,
    bone_groups.POSE_OT_ik_fk_group_to_ik,
    bone_groups.POSE_OT_ik_fk_group_to_fk,
    baking.POSE_OT_ik_fk_bake,
    baking.POSE_OT_ik_fk_bake_current_frame,
    baking.POSE_OT_ik_fk_bake_selected_frames,
    projection.POSE_OT_ik_fk_snapshot_keyframes,
    projection.POSE_OT_ik_fk_print_keyframes,
    preferences.IKFK_AP_preferences,
    ui.VIEW3D_PT_ik_fk_switch,
    bone_groups.IKFK_UL_bone_groups,
    bone_groups.VIEW3D_PT_ik_fk_bone_groups,
    bone_groups.VIEW3D_PT_ik_fk_bone_group_members,
)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ik_fk_projection_frames = bpy.props.CollectionProperty(type=projection.IKFK_PG_projection_frame)
    bpy.types.Scene.ik_fk_bake_step = bpy.props.IntProperty(
        name="Frame Step",
        description="Frame spacing for range baking; the selected end frame is always included",
        default=1,
        min=1,
        soft_max=10,
    )
    bpy.types.Scene.ik_fk_bake_min_samples = bpy.props.IntProperty(
        name="Min Samples",
        description="Minimum evaluations per sampled frame before accepting a stable pose (including the initial read)",
        default=2,
        min=2,
        soft_max=100,
        update=baking._update_min_samples,
    )
    bpy.types.Scene.ik_fk_bake_max_samples = bpy.props.IntProperty(
        name="Max Samples",
        description="Maximum evaluations per sampled frame; cancel baking if the pose is still unstable",
        default=10,
        min=2,
        soft_max=100,
        update=baking._update_max_samples,
    )
    preferences._register_keymaps()


def unregister():
    preferences._unregister_keymaps()
    del bpy.types.Scene.ik_fk_projection_frames
    del bpy.types.Scene.ik_fk_bake_max_samples
    del bpy.types.Scene.ik_fk_bake_min_samples
    del bpy.types.Scene.ik_fk_bake_step
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
