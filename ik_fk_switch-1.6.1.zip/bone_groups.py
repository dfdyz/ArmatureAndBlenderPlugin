# SPDX-License-Identifier: GPL-3.0-or-later
"""Bone collection list, ordering, membership and scoped IK/FK buttons."""

import bpy
from . import switching


class POSE_OT_ik_fk_group_to_ik(switching._SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_group_to_ik"
    bl_label = "组 IK"
    bl_description = "仅对列表选中组的直接成员缓存姿态，禁用 FK_*、写回局部变换，再启用 IK_*；包含隐藏和未选中的成员"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "IK"
    group_only = True


class POSE_OT_ik_fk_group_to_fk(switching._SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_group_to_fk"
    bl_label = "组 FK"
    bl_description = "仅对列表选中组的直接成员缓存姿态，禁用 IK_*、写回局部变换，再启用 FK_*；包含隐藏和未选中的成员"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "FK"
    group_only = True


class IKFK_UL_bone_groups(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # Native Bone Collections keep references valid after renaming bones
        # and are saved with the Armature, including nested collections.
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.enabled = item.is_editable
            row.prop(item, "name", text="", emboss=False, icon="GROUP_BONE")
            if context.active_object.mode != "EDIT":
                layout.label(text=str(len(item.bones)))
        else:
            layout.alignment = "CENTER"
            layout.label(text="", icon="GROUP_BONE")


class VIEW3D_PT_ik_fk_bone_groups(bpy.types.Panel):
    bl_label = "骨骼组"
    bl_idname = "VIEW3D_PT_ik_fk_bone_groups"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_order = 1
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if not obj or obj.type != "ARMATURE":
            layout.label(text="请选择一个骨架", icon="INFO")
            return
        armature = obj.data
        row = layout.row()
        row.template_list(
            "IKFK_UL_bone_groups", "", armature, "collections_all",
            armature.collections, "active_index", rows=5,
        )
        tools = row.column(align=True)
        tools.operator("armature.collection_add", text="", icon="ADD")
        tools.operator("armature.collection_remove", text="", icon="REMOVE")
        tools.separator()
        tools.operator("armature.collection_move", text="", icon="TRIA_UP").direction = "UP"
        tools.operator("armature.collection_move", text="", icon="TRIA_DOWN").direction = "DOWN"
        row = layout.row(align=True)
        row.operator("armature.collection_select", text="选中")
        row.operator("armature.collection_deselect", text="弃选")
        row = layout.row(align=True)
        row.operator(POSE_OT_ik_fk_group_to_ik.bl_idname)
        row.operator(POSE_OT_ik_fk_group_to_fk.bl_idname)
        if obj.mode not in {"POSE", "EDIT"}:
            layout.label(text="进入姿态或编辑模式以管理组成员", icon="INFO")


class VIEW3D_PT_ik_fk_bone_group_members(bpy.types.Panel):
    bl_label = "编辑组成员"
    bl_idname = "VIEW3D_PT_ik_fk_bone_group_members"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_parent_id = "VIEW3D_PT_ik_fk_bone_groups"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return bool(context.active_object and context.active_object.type == "ARMATURE")

    def draw(self, context):
        # Membership changes stay hidden until this child panel is expanded.
        row = self.layout.row(align=True)
        row.operator("armature.collection_assign", text="指定")
        row.operator("armature.collection_unassign", text="移除")
