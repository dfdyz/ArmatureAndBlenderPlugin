# SPDX-License-Identifier: GPL-3.0-or-later
"""Bake the evaluated pose before switching IK_* / FK_* bone constraints."""

import bpy
import rna_keymap_ui
from math import floor, isfinite


bl_info = {
    "name": "IK / FK Switch",
    "author": "IK / FK Switch Contributors",
    "version": (1, 5, 3),
    "blender": (4, 5, 0),
    "location": "3D Viewport > Sidebar > IK / FK",
    "description": "Bake the current pose and switch IK_* / FK_* constraints",
    "category": "Rigging",
}


def _bone_levels(armature):
    """Return every pose bone, with parents in an earlier level."""
    level = [bone for bone in armature.pose.bones if bone.parent is None]
    levels = []
    while level:
        levels.append(level)
        level = [child for bone in level for child in bone.children]
    return levels


def _world_pose(context, armature):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = armature.evaluated_get(depsgraph)
    # PoseBone.matrix is in armature space and includes evaluated constraints.
    # Copy values: dependency graph updates invalidate evaluated data references.
    return {
        bone.name: evaluated.matrix_world @ bone.matrix
        for bone in evaluated.pose.bones
    }


_POSE_STABILITY_TOLERANCE = 1e-6


def _pose_delta(previous, current):
    largest, changed_bone = 0.0, ""
    for name, matrix in current.items():
        for row in range(4):
            for column in range(4):
                delta = abs(matrix[row][column] - previous[name][row][column])
                if not isfinite(delta):
                    raise RuntimeError(f"Non-finite pose matrix on bone '{name}'")
                if delta > largest:
                    largest, changed_bone = delta, name
    return largest, changed_bone


def _stable_world_pose(context, armature, *, frame=None):
    """Require consecutive evaluated world poses to agree before baking.

    Animated sampling re-evaluates the same frame. Current-pose sampling tags
    object transforms instead, preserving unkeyed edits and avoiding an
    animation reset. Plain view_layer.update() does not dirty cyclic inputs.
    """
    minimum = context.scene.ik_fk_bake_min_samples
    maximum = context.scene.ik_fk_bake_max_samples
    previous = None
    delta, changed_bone = 0.0, ""
    for attempt in range(maximum):
        if frame is not None:
            context.scene.frame_set(floor(frame), subframe=frame - floor(frame))
        elif attempt:
            # Include constraint targets and other rigs in the view layer:
            # an inter-object dependency cycle may cross armature boundaries.
            # Do not tag TIME/ANIMATION, which would discard manual edits.
            for obj in context.view_layer.objects:
                obj.update_tag(refresh={"OBJECT"})
        current = _world_pose(context, armature)
        if previous is not None:
            delta, changed_bone = _pose_delta(previous, current)
            # The initial read counts as one sample. Never accept an early
            # agreement before the user's minimum number of evaluations.
            if attempt + 1 >= minimum and delta <= _POSE_STABILITY_TOLERANCE:
                return current
        previous = current

    current_frame = context.scene.frame_current + context.scene.frame_subframe
    raise RuntimeError(
        f"Pose did not stabilize at frame {current_frame:g} after "
        f"{maximum} evaluations "
        f"(bone '{armature.name}/{changed_bone}', matrix delta {delta:.6g})"
    )


def _local_channels(bone):
    """Keep original channels, including Euler winding, for error recovery."""
    return {
        "location": bone.location.copy(),
        "rotation_euler": bone.rotation_euler.copy(),
        "rotation_quaternion": bone.rotation_quaternion.copy(),
        "rotation_axis_angle": tuple(bone.rotation_axis_angle),
        "scale": bone.scale.copy(),
    }


def _world_to_local_pose(context, armature, world_matrices):
    """Calculate ALL local matrices before changing constraints or channels."""
    evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
    world_to_armature = evaluated.matrix_world.inverted()
    pose_matrices = {
        name: world_to_armature @ matrix for name, matrix in world_matrices.items()
    }
    local_matrices = {}
    for bone in armature.pose.bones:
        parent_args = {}
        if bone.parent:
            parent_args = {
                # Use the parent's captured constrained pose, never its pose
                # after constraints have been muted or channels overwritten.
                "parent_matrix": pose_matrices[bone.parent.name],
                "parent_matrix_local": bone.parent.bone.matrix_local,
            }
        # Handles rest matrices, Local Location, Inherit Rotation and the
        # different Inherit Scale modes. A plain parent inverse does not.
        local_matrices[bone.name] = bone.bone.convert_local_to_pose(
            pose_matrices[bone.name],
            bone.bone.matrix_local,
            invert=True,
            **parent_args,
        )
    return local_matrices


def _apply_local_pose(context, local_matrices, levels):
    """Apply the cached local matrices only after old constraints are muted."""
    for level in levels:
        for bone in level:
            bone.matrix_basis = local_matrices[bone.name]
        context.view_layer.update()


def switch_mode(context, mode):
    """Snapshot -> cache local matrices -> mute -> apply pose -> optionally unmute.

    Constraint influence and animation are deliberately preserved. Returns the
    number of constraints matched by the disable and enable prefixes.
    DISABLE_ALL mutes both IK_* and FK_* and never unmutes any constraints.
    """
    if mode not in {"IK", "FK", "DISABLE_ALL"}:
        raise ValueError("Mode must be IK, FK or DISABLE_ALL")
    armature = context.active_object
    if not (
        armature
        and armature.type == "ARMATURE"
        and armature.mode == "POSE"
        and armature.is_editable
    ):
        raise ValueError("Select an editable armature in Pose Mode")

    levels = _bone_levels(armature)
    world_matrices = _world_pose(context, armature)
    local_matrices = _world_to_local_pose(context, armature, world_matrices)
    old_channels = {
        bone.name: _local_channels(bone) for bone in armature.pose.bones
    }
    if mode == "DISABLE_ALL":
        disable_prefixes = ("IK_", "FK_")
        enable_prefixes = ()
    else:
        disable_prefixes = ("FK_",) if mode == "IK" else ("IK_",)
        enable_prefixes = (mode + "_",)
    disable = []
    enable = []
    for bone in armature.pose.bones:
        for constraint in bone.constraints:
            # Case-sensitive prefix matching is equivalent to FK_* / IK_*.
            if constraint.name.startswith(disable_prefixes):
                disable.append(constraint)
            elif constraint.name.startswith(enable_prefixes):
                enable.append(constraint)
    old_mutes = [(constraint, constraint.mute) for constraint in disable + enable]

    try:
        # Finish disabling ALL old-mode constraints before enabling ANY new
        # ones. Do not interleave disable/enable operations while scanning.
        for constraint in disable:
            constraint.mute = True
        context.view_layer.update()

        _apply_local_pose(context, local_matrices, levels)

        for constraint in enable:
            constraint.mute = False
        context.view_layer.update()
    except Exception:
        # A cancelled operator should not leave a partially switched rig.
        for name, channels in old_channels.items():
            bone = armature.pose.bones[name]
            for attribute, value in channels.items():
                setattr(bone, attribute, value)
        for constraint, muted in old_mutes:
            constraint.mute = muted
        context.view_layer.update()
        raise

    return len(disable), len(enable)


def _action_curve_collections(armature):
    """Read only this object's assigned Action slot (including legacy Actions)."""
    animation = armature.animation_data
    if not animation or not animation.action:
        return []
    action = animation.action
    if action.is_action_legacy:
        return [action.fcurves]
    slot = animation.action_slot
    if slot is None:
        return []
    collections = []
    for layer in action.layers:
        for strip in layer.strips:
            if strip.type == "KEYFRAME":
                channelbag = strip.channelbag(slot)
                if channelbag is not None:
                    collections.append(channelbag.fcurves)
    return collections


def _selected_keyframe_times(armature, bones=None):
    # Projection snapshots only need times, so they may read every channel
    # in the active slot. Baking still filters by its selected pose bones.
    prefixes = None if bones is None else tuple(
        bone.path_from_id() + suffix for bone in bones for suffix in (".", "[")
    )
    animation = armature.animation_data
    times = set()
    for curves in _action_curve_collections(armature):
        for curve in curves:
            if prefixes is not None and not curve.data_path.startswith(prefixes):
                continue
            for key in curve.keyframe_points:
                if key.select_control_point:
                    frame = key.co.x
                    if animation.use_tweak_mode:
                        frame = animation.nla_tweak_strip_time_to_scene(frame)
                    # Location/rotation/scale channels on one frame count once.
                    times.add(round(frame, 6))
    return sorted(times)


def _bake_frame_times(context, armature, bones, step, selected_only=False):
    selected = _selected_keyframe_times(armature, bones)
    if selected_only:
        if not selected:
            raise ValueError("Select at least one keyframe on the selected bones")
        return selected
    if not isinstance(step, int) or step < 1:
        raise ValueError("Frame Step must be a positive integer")
    if len(selected) < 2:
        # Do not jump to a single selected key, or reset manually edited poses.
        return [context.scene.frame_current + context.scene.frame_subframe]
    start, end = selected[0], selected[-1]
    frames = [start + offset * step for offset in range(floor((end - start) / step) + 1)]
    if abs(frames[-1] - end) > 1e-6:
        frames.append(end)
    return frames


def _rotation_path(bone):
    if bone.rotation_mode == "QUATERNION":
        return "rotation_quaternion"
    if bone.rotation_mode == "AXIS_ANGLE":
        return "rotation_axis_angle"
    return "rotation_euler"


_KEYFRAME_ATTRIBUTES = (
    "co", "handle_left", "handle_right", "handle_left_type", "handle_right_type",
    "interpolation", "easing", "amplitude", "back", "period", "type",
    "select_control_point", "select_left_handle", "select_right_handle",
)


def _snapshot_transform_keys(armature, bones):
    paths = {
        bone.path_from_id(path)
        for bone in bones for path in ("location", _rotation_path(bone), "scale")
    }
    snapshots = {}
    for curves in _action_curve_collections(armature):
        for curve in curves:
            if curve.data_path in paths:
                points = []
                for key in curve.keyframe_points:
                    values = {}
                    for attribute in _KEYFRAME_ATTRIBUTES:
                        value = getattr(key, attribute)
                        values[attribute] = value.copy() if hasattr(value, "copy") else value
                    points.append(values)
                snapshots[curve.as_pointer()] = points
    return paths, snapshots


def _restore_transform_keys(armature, paths, snapshots):
    for curves in _action_curve_collections(armature):
        for curve in list(curves):
            if curve.data_path not in paths:
                continue
            points = snapshots.get(curve.as_pointer())
            if points is None:
                curves.remove(curve)
                continue
            curve.keyframe_points.clear()
            curve.keyframe_points.add(len(points))
            for key, values in zip(curve.keyframe_points, points):
                for attribute, value in values.items():
                    setattr(key, attribute, value)
            curve.update()


def _rollback_transform_keys(armature, original_action, had_animation_data, paths, snapshots):
    if original_action:
        _restore_transform_keys(armature, paths, snapshots)
    elif armature.animation_data:
        new_action = armature.animation_data.action
        armature.animation_data.action = None
        if not had_animation_data:
            armature.animation_data_clear()
        if new_action and new_action.users == 0:
            bpy.data.actions.remove(new_action)


def _insert_transform_keys(bones, frame, previous_rotations):
    for bone in bones:
        rotation_path = _rotation_path(bone)
        if rotation_path != "rotation_axis_angle":
            rotation = getattr(bone, rotation_path).copy()
            previous = previous_rotations.get(bone.name)
            if previous is not None:
                rotation.make_compatible(previous)
                setattr(bone, rotation_path, rotation)
            previous_rotations[bone.name] = rotation
        for path in ("location", rotation_path, "scale"):
            if not bone.keyframe_insert(data_path=path, index=-1, frame=frame, options=set()):
                raise RuntimeError(f"Could not insert {bone.name}: {path} at frame {frame:g}")


def bake_pose(context, step=1, *, selected_only=False, current_only=False):
    """Sample with the existing local conversion, then key selected pose bones.

    No constraint is toggled. A single selected frame means key the current
    pose at the playhead; two or more distinct frames define a bake interval.
    With selected_only=True, sample the exact selected times, even a lone key.
    With current_only=True, ignore key selection and bake the current pose.
    """
    if not _SwitchModeOperator.poll(context):
        raise ValueError("Select an editable armature in Pose Mode")
    armature = context.active_object
    bones = [bone for bone in armature.pose.bones if bone.bone.select]
    if not bones:
        raise ValueError("Select at least one pose bone to bake")
    if current_only and selected_only:
        raise ValueError("Choose either current-frame or selected-frame baking")
    frames = (
        [context.scene.frame_current + context.scene.frame_subframe]
        if current_only else _bake_frame_times(context, armature, bones, step, selected_only)
    )
    sample_animation = not current_only and (selected_only or len(frames) > 1)
    names = {bone.name for bone in bones}
    levels = [
        [bone for bone in level if bone.name in names]
        for level in _bone_levels(armature)
    ]
    levels = [level for level in levels if level]
    scene = context.scene
    original_frame, original_subframe = scene.frame_current, scene.frame_subframe
    old_channels = {bone.name: _local_channels(bone) for bone in armature.pose.bones}
    had_animation_data = armature.animation_data is not None
    original_action = armature.animation_data.action if had_animation_data else None
    if original_action and not original_action.is_editable:
        raise ValueError("The active Action is not editable")
    paths, original_keys = _snapshot_transform_keys(armature, bones)
    writing = False
    success = False
    try:
        samples = []
        for frame in frames:
            world = _stable_world_pose(
                context, armature, frame=frame if sample_animation else None,
            )
            local = _world_to_local_pose(context, armature, world)
            samples.append((frame, {name: local[name] for name in names}))

        # Finish sampling the original animation before inserting ANY keys.
        writing = True
        previous_rotations = {}
        for frame, local in samples:
            _apply_local_pose(context, local, levels)
            _insert_transform_keys(bones, frame, previous_rotations)
        # Restore a stable displayed pose as well. If the written animation
        # does not settle, use the same keyframe rollback as other failures.
        _stable_world_pose(
            context, armature,
            frame=original_frame + original_subframe if sample_animation else None,
        )
        success = True
    except Exception:
        if writing:
            _rollback_transform_keys(armature, original_action, had_animation_data, paths, original_keys)
        raise
    finally:
        if sample_animation and not success:
            scene.frame_set(original_frame, subframe=original_subframe)
        if not success:
            for name, channels in old_channels.items():
                for attribute, value in channels.items():
                    setattr(armature.pose.bones[name], attribute, value)
        context.view_layer.update()
    return len(bones), frames


def snapshot_keyframe_times(context):
    """Store only selected scene-frame numbers, without source-rig references."""
    armature = context.active_object
    if not armature or armature.type != "ARMATURE":
        raise ValueError("Select an armature to snapshot keyframe times")
    frames = _selected_keyframe_times(armature)
    if not frames:
        raise ValueError("Select at least one keyframe in the active armature's Action")
    snapshot = context.scene.ik_fk_projection_frames
    snapshot.clear()
    for frame in frames:
        snapshot.add().frame = frame
    return frames


def print_keyframe_times(context):
    """Key one current set of local channels at all snapshotted frame times."""
    if not _SwitchModeOperator.poll(context):
        raise ValueError("Select an editable armature in Pose Mode")
    armature = context.active_object
    bones = [bone for bone in armature.pose.bones if bone.bone.select]
    if not bones:
        raise ValueError("Select at least one pose bone to print keyframes")
    frames = sorted({item.frame for item in context.scene.ik_fk_projection_frames})
    if not frames:
        raise ValueError("Snapshot keyframe times before printing")
    channels = {bone.name: _local_channels(bone) for bone in bones}
    had_animation_data = armature.animation_data is not None
    original_action = armature.animation_data.action if had_animation_data else None
    if original_action and not original_action.is_editable:
        raise ValueError("The active Action is not editable")
    paths, original_keys = _snapshot_transform_keys(armature, bones)
    try:
        previous_rotations = {}
        for frame in frames:
            # Never frame_set(): every destination gets the same current pose,
            # including unkeyed edits, regardless of its existing animation.
            _insert_transform_keys(bones, frame, previous_rotations)
    except Exception:
        _rollback_transform_keys(armature, original_action, had_animation_data, paths, original_keys)
        raise
    finally:
        for bone in bones:
            for attribute, value in channels[bone.name].items():
                setattr(bone, attribute, value)
        context.view_layer.update()
    return len(bones), frames


class _SwitchModeOperator:
    @classmethod
    def poll(cls, context):
        armature = context.active_object
        return bool(
            armature
            and armature.type == "ARMATURE"
            and armature.mode == "POSE"
            and armature.is_editable
        )

    def execute(self, context):
        try:
            disabled, enabled = switch_mode(context, self.target_mode)
        except Exception as error:
            self.report({"ERROR"}, f"IK / FK switch failed: {error}")
            return {"CANCELLED"}
        self.report(
            {"INFO"},
            f"{self.bl_label}: disabled {disabled}, enabled {enabled} constraints",
        )
        return {"FINISHED"}


class POSE_OT_ik_fk_switch_to_ik(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_switch_to_ik"
    bl_label = "IK Mode"
    bl_description = "Bake the current pose, disable FK_* and enable IK_* constraints"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "IK"


class POSE_OT_ik_fk_switch_to_fk(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_switch_to_fk"
    bl_label = "FK Mode"
    bl_description = "Bake the current pose, disable IK_* and enable FK_* constraints"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "FK"


class POSE_OT_ik_fk_disable_all(_SwitchModeOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_disable_all"
    bl_label = "DisableAll"
    bl_description = "Cache the current pose, disable IK_* and FK_*, then apply the pose"
    bl_options = {"REGISTER", "UNDO"}
    target_mode = "DISABLE_ALL"


class _BakePoseOperator:
    selected_only = False
    current_only = False

    @classmethod
    def poll(cls, context):
        return _SwitchModeOperator.poll(context) and any(
            bone.bone.select for bone in context.active_object.pose.bones
        )

    def execute(self, context):
        try:
            count, frames = bake_pose(
                context, context.scene.ik_fk_bake_step, selected_only=self.selected_only,
                current_only=self.current_only,
            )
        except Exception as error:
            self.report({"ERROR"}, f"Bake failed: {error}")
            return {"CANCELLED"}
        interval = f"{frames[0]:g}" if len(frames) == 1 else f"{frames[0]:g}-{frames[-1]:g}"
        self.report({"INFO"}, f"Baked {count} bones, {len(frames)} frames ({interval})")
        return {"FINISHED"}


class POSE_OT_ik_fk_bake(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake"
    bl_label = "Bake"
    bl_description = "Key selected bones at the current frame, or bake between two or more selected frames"
    bl_options = {"REGISTER", "UNDO"}


class POSE_OT_ik_fk_bake_current_frame(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake_current_frame"
    bl_label = "烘焙到当前帧"
    bl_description = "忽略关键帧选择，将所选骨骼的当前约束姿态烘焙到播放头所在帧，保留未插帧的手动调整"
    bl_options = {"REGISTER", "UNDO"}
    current_only = True


class POSE_OT_ik_fk_bake_selected_frames(_BakePoseOperator, bpy.types.Operator):
    bl_idname = "pose.ik_fk_bake_selected_frames"
    bl_label = "烘焙选中帧"
    bl_description = "在所有选中的关键帧位置重采样并烘焙所选骨骼，不填充中间帧"
    bl_options = {"REGISTER", "UNDO"}
    selected_only = True


class IKFK_PG_projection_frame(bpy.types.PropertyGroup):
    frame: bpy.props.FloatProperty(name="Frame", options=set())


class POSE_OT_ik_fk_snapshot_keyframes(bpy.types.Operator):
    bl_idname = "pose.ik_fk_snapshot_keyframes"
    bl_label = "快照"
    bl_description = "记录当前活动骨架 Action 中选中的帧号，仅保存帧号，可用于其他骨架"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(context.active_object and context.active_object.type == "ARMATURE")

    def execute(self, context):
        try:
            frames = snapshot_keyframe_times(context)
        except Exception as error:
            self.report({"ERROR"}, f"快照失败：{error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已记录 {len(frames)} 个帧号")
        return {"FINISHED"}


class POSE_OT_ik_fk_print_keyframes(bpy.types.Operator):
    bl_idname = "pose.ik_fk_print_keyframes"
    bl_label = "打印"
    bl_description = "将当前所选骨骼的位置、旋转和缩放写入快照记录的所有帧号"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return POSE_OT_ik_fk_bake.poll(context) and bool(context.scene.ik_fk_projection_frames)

    def execute(self, context):
        try:
            count, frames = print_keyframe_times(context)
        except Exception as error:
            self.report({"ERROR"}, f"打印失败：{error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已为 {count} 根骨骼打印 {len(frames)} 帧")
        return {"FINISHED"}


_SHORTCUTS = (
    (POSE_OT_ik_fk_switch_to_ik, "I"),
    (POSE_OT_ik_fk_switch_to_fk, "F"),
    (POSE_OT_ik_fk_bake, "B"),
)
_addon_keymaps = []


def _register_keymaps():
    keyconfig = bpy.context.window_manager.keyconfigs.addon
    if keyconfig is None:
        return  # Key configurations can be unavailable in background sessions.
    keymap = keyconfig.keymaps.new(name="Pose", space_type="EMPTY", region_type="WINDOW")
    for operator, key in _SHORTCUTS:
        item = keymap.keymap_items.new(
            operator.bl_idname, type=key, value="PRESS", ctrl=True, shift=True,
        )
        _addon_keymaps.append((keymap, item))


def _unregister_keymaps():
    for keymap, item in _addon_keymaps:
        keymap.keymap_items.remove(item)
    _addon_keymaps.clear()


class IKFK_AP_preferences(bpy.types.AddonPreferences):
    # Extensions use the full bl_ext.<repository>.<package> module identifier.
    bl_idname = __package__ or __name__

    def draw(self, context):
        layout = self.layout
        layout.label(text="Shortcuts (Pose Mode)")
        # Edit the USER keymap, not the add-on defaults, so Blender can save
        # custom bindings and restore defaults through its native keymap UI.
        keyconfig = context.window_manager.keyconfigs.user
        keymap = keyconfig.keymaps.get("Pose") if keyconfig else None
        for operator, _key in _SHORTCUTS:
            items = (
                [item for item in keymap.keymap_items if item.idname == operator.bl_idname]
                if keymap else []
            )
            if not items:
                layout.label(text=f"{operator.bl_label}: unassigned (Preferences > Keymap)")
                continue
            for item in items:
                column = layout.column()
                column.context_pointer_set("keymap", keymap)
                rna_keymap_ui.draw_kmi([], keyconfig, keymap, item, column, 0)


class VIEW3D_PT_ik_fk_switch(bpy.types.Panel):
    bl_label = "IK / FK Switch"
    bl_idname = "VIEW3D_PT_ik_fk_switch"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        available = _SwitchModeOperator.poll(context)
        column = layout.column(align=True)
        column.enabled = available
        column.scale_y = 1.4
        modes = column.row(align=True)
        modes.operator(POSE_OT_ik_fk_switch_to_ik.bl_idname, text="IK Mode")
        modes.operator(POSE_OT_ik_fk_switch_to_fk.bl_idname, text="FK Mode")
        column.operator(POSE_OT_ik_fk_disable_all.bl_idname, text="DisableAll")
        layout.separator()
        bake_column = layout.column(align=True)
        bake_column.enabled = POSE_OT_ik_fk_bake.poll(context)
        bake_column.prop(context.scene, "ik_fk_bake_step")
        bake_column.prop(context.scene, "ik_fk_bake_min_samples")
        bake_column.prop(context.scene, "ik_fk_bake_max_samples")
        bake_column.operator(POSE_OT_ik_fk_bake.bl_idname, text="Bake")
        bake_column.operator(POSE_OT_ik_fk_bake_current_frame.bl_idname)
        bake_column.operator(POSE_OT_ik_fk_bake_selected_frames.bl_idname)
        layout.separator()
        projection = layout.box()
        projection.label(text="关键帧投影")
        row = projection.row(align=True)
        row.operator(POSE_OT_ik_fk_snapshot_keyframes.bl_idname)
        row.operator(POSE_OT_ik_fk_print_keyframes.bl_idname)
        projection.label(text=f"已记录 {len(context.scene.ik_fk_projection_frames)} 个帧号")
        if not available:
            layout.label(text="Select an armature in Pose Mode", icon="INFO")


class IKFK_UL_bone_groups(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # Native Bone Collections keep references valid after renaming bones
        # and are saved with the Armature, including nested collections.
        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row = layout.row(align=True)
            row.enabled = item.is_editable
            row.prop(item, "name", text="", emboss=False, icon="GROUP_BONE")
            if context.active_object.mode != "EDIT":
                layout.label(text=str(len(item.bones)))
        else:
            layout.alignment = "CENTER"
            layout.label(text="", icon="GROUP_BONE")


class VIEW3D_PT_ik_fk_bone_groups(bpy.types.Panel):
    bl_label = "骨骼组"
    bl_idname = "VIEW3D_PT_ik_fk_bone_groups"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_order = 1
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if not obj or obj.type != "ARMATURE":
            layout.label(text="请选择一个骨架", icon="INFO")
            return
        armature = obj.data
        row = layout.row()
        row.template_list(
            "IKFK_UL_bone_groups", "", armature, "collections_all",
            armature.collections, "active_index", rows=5,
        )
        tools = row.column(align=True)
        tools.operator("armature.collection_add", text="", icon="ADD")
        tools.operator("armature.collection_remove", text="", icon="REMOVE")
        row = layout.row(align=True)
        row.operator("armature.collection_select", text="选中")
        row.operator("armature.collection_deselect", text="弃选")
        if obj.mode not in {"POSE", "EDIT"}:
            layout.label(text="进入姿态或编辑模式以管理组成员", icon="INFO")


class VIEW3D_PT_ik_fk_bone_group_members(bpy.types.Panel):
    bl_label = "编辑组成员"
    bl_idname = "VIEW3D_PT_ik_fk_bone_group_members"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "IK / FK"
    bl_parent_id = "VIEW3D_PT_ik_fk_bone_groups"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return bool(context.active_object and context.active_object.type == "ARMATURE")

    def draw(self, context):
        # Membership changes stay hidden until this child panel is expanded.
        row = self.layout.row(align=True)
        row.operator("armature.collection_assign", text="指定")
        row.operator("armature.collection_unassign", text="移除")


_CLASSES = (
    IKFK_PG_projection_frame,
    POSE_OT_ik_fk_switch_to_ik,
    POSE_OT_ik_fk_switch_to_fk,
    POSE_OT_ik_fk_disable_all,
    POSE_OT_ik_fk_bake,
    POSE_OT_ik_fk_bake_current_frame,
    POSE_OT_ik_fk_bake_selected_frames,
    POSE_OT_ik_fk_snapshot_keyframes,
    POSE_OT_ik_fk_print_keyframes,
    IKFK_AP_preferences,
    VIEW3D_PT_ik_fk_switch,
    IKFK_UL_bone_groups,
    VIEW3D_PT_ik_fk_bone_groups,
    VIEW3D_PT_ik_fk_bone_group_members,
)


def _update_min_samples(scene, _context):
    if scene.ik_fk_bake_min_samples > scene.ik_fk_bake_max_samples:
        scene.ik_fk_bake_max_samples = scene.ik_fk_bake_min_samples


def _update_max_samples(scene, _context):
    if scene.ik_fk_bake_max_samples < scene.ik_fk_bake_min_samples:
        scene.ik_fk_bake_min_samples = scene.ik_fk_bake_max_samples


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.ik_fk_projection_frames = bpy.props.CollectionProperty(type=IKFK_PG_projection_frame)
    bpy.types.Scene.ik_fk_bake_step = bpy.props.IntProperty(
        name="Frame Step",
        description="Frame spacing for range baking; the selected end frame is always included",
        default=1,
        min=1,
        soft_max=10,
    )
    bpy.types.Scene.ik_fk_bake_min_samples = bpy.props.IntProperty(
        name="Min Samples",
        description="Minimum evaluations per sampled frame before accepting a stable pose (including the initial read)",
        default=2,
        min=2,
        soft_max=100,
        update=_update_min_samples,
    )
    bpy.types.Scene.ik_fk_bake_max_samples = bpy.props.IntProperty(
        name="Max Samples",
        description="Maximum evaluations per sampled frame; cancel baking if the pose is still unstable",
        default=10,
        min=2,
        soft_max=100,
        update=_update_max_samples,
    )
    _register_keymaps()


def unregister():
    _unregister_keymaps()
    del bpy.types.Scene.ik_fk_projection_frames
    del bpy.types.Scene.ik_fk_bake_max_samples
    del bpy.types.Scene.ik_fk_bake_min_samples
    del bpy.types.Scene.ik_fk_bake_step
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
